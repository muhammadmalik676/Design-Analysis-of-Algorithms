# Project Demo
# CS 412 Algorithms: Design and Analysis, Spring 2022

-----

This folder contains the demo. A skeleton file `demo.tex` is provided in which you will enter your presentation. Images are to be used from `../images/` and references from  `../refs.bib`.

# Discussion

Please discuss the project and any related thoughts on [the dedicated discussion thread on Canvas](https://hulms.instructure.com/courses/1921/discussion_topics/18100).
