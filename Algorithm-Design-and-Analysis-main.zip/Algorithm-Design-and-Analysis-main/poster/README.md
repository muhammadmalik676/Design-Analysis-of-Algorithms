# Project Poster
# CS 412 Algorithms: Design and Analysis, Spring 2022

-----

This folder contains the poster. A skeleton file `poster.tex` is provided in which you will enter your poster. Images are to be used from `../images/` and references from  `../refs.bib`.

# Discussion

Please discuss the project and any related thoughts on [the dedicated discussion thread on Canvas](https://hulms.instructure.com/courses/1921/discussion_topics/18100).
